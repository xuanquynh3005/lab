import cv2
import numpy as np
from scipy.fftpack import dct, idct
import matplotlib.pyplot as plt

def block_process(image, block_size, func):
    h, w = image.shape
    output = np.zeros_like(image, dtype=np.float32)
    for r in range(0, h, block_size):
        for c in range(0, w, block_size):
            block = image[r:r+block_size, c:c+block_size]
            processed_block = func(block)
            output[r:r+block_size, c:c+block_size] = processed_block
    return output

def dct2(block):
    return dct(dct(block.T, norm='ortho').T, norm='ortho')

def idct2(block):
    return idct(idct(block.T, norm='ortho').T, norm='ortho')

def block_energy(dct_block):
    # Ignore DC coefficient at (0,0)
    ac = np.copy(dct_block)
    ac[0,0] = 0
    energy = np.sum(ac**2)
    return energy

def embed_watermark(original, watermark_bits, block_size=8):
    img = original.astype(np.float32)
    h, w = img.shape
    wm_len = len(watermark_bits)

    # Pad image to multiple of block_size if needed
    pad_r = (block_size - h % block_size) % block_size
    pad_c = (block_size - w % block_size) % block_size
    img_padded = np.pad(img, ((0,pad_r), (0,pad_c)), mode='constant')
    h_p, w_p = img_padded.shape

    # Step 1: Compute DCT for all blocks and energy map
    dct_blocks = []
    energies = []
    for r in range(0, h_p, block_size):
        for c in range(0, w_p, block_size):
            block = img_padded[r:r+block_size, c:c+block_size]
            dct_block = dct2(block)
            dct_blocks.append(dct_block)
            energies.append(block_energy(dct_block))
    energies = np.array(energies)

    # Step 2: Choose threshold - We pick median energy to adaptively embed only in high-energy blocks
    energy_threshold = np.median(energies)
    high_energy_indices = np.where(energies > energy_threshold)[0]

    if len(high_energy_indices) < wm_len:
        print(f"Warning: watermark length ({wm_len}) exceeds number of high-energy blocks ({len(high_energy_indices)}). Some bits won't be embedded.")

    # Step 3: Embed watermark bits into mid-frequency DCT coefficients of selected blocks
    # We'll modulate the (4,1) DCT coefficient (low-mid frequency)
    coef_pos = (4, 1)
    alpha = 10  # embedding strength coefficient

    for i, bit in enumerate(watermark_bits):
        if i >= len(high_energy_indices):
            break
        idx = high_energy_indices[i]
        dct_block = dct_blocks[idx]
        # Embed bit: if bit=1 increase coefficient by alpha, else decrease by alpha
        if bit == '1':
            dct_block[coef_pos] += alpha
        else:
            dct_block[coef_pos] -= alpha
        dct_blocks[idx] = dct_block

    # Step 4: Reconstruct watermarked image from modified DCT blocks
    img_wm = np.zeros_like(img_padded)
    count = 0
    for r in range(0, h_p, block_size):
        for c in range(0, w_p, block_size):
            block_idct = idct2(dct_blocks[count])
            img_wm[r:r+block_size, c:c+block_size] = block_idct
            count +=1

    # Crop to original image size
    img_wm_cropped = img_wm[:h, :w]

    # Clip and convert to uint8
    img_wm_cropped = np.clip(img_wm_cropped, 0, 255).astype(np.uint8)

    embedding_info = {
        'energy_threshold': energy_threshold,
        'high_energy_blocks': len(high_energy_indices),
        'embedded_bits': min(wm_len, len(high_energy_indices))
    }

    return img_wm_cropped, embedding_info

def extract_watermark(original, watermarked, watermark_length, block_size=8):
    img_orig = original.astype(np.float32)
    img_wm = watermarked.astype(np.float32)
    h, w = img_orig.shape

    pad_r = (block_size - h % block_size) % block_size
    pad_c = (block_size - w % block_size) % block_size
    img_orig_padded = np.pad(img_orig, ((0,pad_r),(0,pad_c)), mode='constant')
    img_wm_padded = np.pad(img_wm, ((0,pad_r),(0,pad_c)), mode='constant')
    h_p, w_p = img_orig_padded.shape

    # Compute DCT blocks and energies for original image
    orig_dct_blocks = []
    energies = []
    for r in range(0, h_p, block_size):
        for c in range(0, w_p, block_size):
            block = img_orig_padded[r:r+block_size, c:c+block_size]
            dct_block = dct2(block)
            orig_dct_blocks.append(dct_block)
            energies.append(block_energy(dct_block))
    energies = np.array(energies)
    energy_threshold = np.median(energies)
    high_energy_indices = np.where(energies > energy_threshold)[0]

    coef_pos = (4, 1)

    extracted_bits = []
    for i in range(watermark_length):
        if i >= len(high_energy_indices):
            break
        idx = high_energy_indices[i]
        orig_coef = orig_dct_blocks[idx][coef_pos]
        wm_block = img_wm_padded[(idx*(block_size*block_size))//(w_p//block_size): , :]  # Ignore this one
        # Instead, compute DCT of watermarked image block:
        r = (idx * block_size) // w_p * block_size
        c = (idx * block_size) % w_p
        block_wm = img_wm_padded[r:r+block_size, c:c+block_size]
        wm_dct_block = dct2(block_wm)
        wm_coef = wm_dct_block[coef_pos]

        # If coefficient higher than original, bit is 1 else 0
        bit = '1' if wm_coef > orig_coef else '0'
        extracted_bits.append(bit)

    return ''.join(extracted_bits)

def string_to_bits(s):
    return ''.join(f'{ord(c):08b}' for c in s)

def bits_to_string(b):
    chars = [b[i:i+8] for i in range(0, len(b), 8)]
    return ''.join(chr(int(c, 2)) for c in chars if len(c) == 8)

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Adaptive DCT Watermarking Lab")
    parser.add_argument('image_path', help='Path to grayscale input image (e.g. .png, .jpg)')
    parser.add_argument('--watermark', default='HELLO_DCT', help='Watermark string (max 16 chars)')
    parser.add_argument('--block_size', type=int, default=8, help='Block size for DCT (default 8)')
    args = parser.parse_args()

    img = cv2.imread(args.image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print("Error: Cannot read image. Make sure the path is correct and image is grayscale or convertible.")
        return

    watermark = args.watermark[:16]  # max 16 chars
    watermark_bits = string_to_bits(watermark)
    print(f"Watermark to embed: '{watermark}'")


    watermarked_img, info = embed_watermark(img, watermark_bits, block_size=args.block_size)


    # Save watermarked image
    out_path = 'watermarked.png'
    cv2.imwrite(out_path, watermarked_img)
    print(f"Watermarked image saved as {out_path}")

    # Extract watermark back
    extracted_bits = extract_watermark(img, watermarked_img, len(watermark_bits), block_size=args.block_size)
    extracted_watermark = bits_to_string(extracted_bits)


    # Display original and watermarked images side-by-side using matplotlib for visualization
    plt.figure(figsize=(10,5))
    plt.subplot(1,2,1)
    plt.title('Original Image')
    plt.axis('off')
    plt.imshow(img, cmap='gray')

    plt.subplot(1,2,2)
    plt.title('Watermarked Image')
    plt.axis('off')
    plt.imshow(watermarked_img, cmap='gray')

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()

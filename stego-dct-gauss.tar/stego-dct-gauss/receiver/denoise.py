import cv2
import numpy as np
from scipy.fftpack import dct

# Hàm khử nhiễu bằng Gaussian Blur (dễ áp dụng, nhẹ nhàng)
def denoise_gaussian(image, seed=42):
    np.random.seed(seed)  # Đảm bảo khử nhiễu ổn định
    return cv2.GaussianBlur(image, (3, 3), 0)

# Hàm khử nhiễu mạnh bằng Non-Local Means
def denoise_nl_means(image):
    return cv2.fastNlMeansDenoising(image, None, h=9, templateWindowSize=9, searchWindowSize=23)

# Hàm khử nhiễu bằng Bilateral Filtering
def denoise_bilateral(image, d=23, sigmaColor=75, sigmaSpace=75):
    return cv2.bilateralFilter(image, d, sigmaColor, sigmaSpace)

def extract_watermark(img, num_bits, block_size=8, threshold=0):  # threshold = 0
    h, w = img.shape
    bits = []
    bit_idx = 0
    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            if bit_idx >= num_bits:
                break
            block = img[i:i+block_size, j:j+block_size]
            if block.shape != (block_size, block_size):
                continue
            dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
            coeff = dct_block[4, 4]
            bits.append(1 if coeff > threshold else 0)
            bit_idx += 1
    return bits

def bits_to_text(bits):
    chars = [chr(int(''.join(str(bit) for bit in bits[i:i+8]), 2)) for i in range(0, len(bits), 8)]
    return ''.join(chars)

# === MAIN ===
noisy_img = cv2.imread("watermarked_noisy.png", cv2.IMREAD_GRAYSCALE)
if noisy_img is None:
    print("Không đọc được ảnh watermarked_noisy.png")
    exit()

# Chọn phương pháp khử nhiễu: Gaussian Blur hoặc Non-Local Means
denoised = denoise_nl_means(noisy_img)
# denoised = denoise_bilateral(noisy_img)
# denoised = denoise_gaussian(noisy_img, seed=42)  # Hoặc thử denoise_nl_means(noisy_img)
bits = extract_watermark(denoised, num_bits=40, threshold=0)  # threshold = 0
message = bits_to_text(bits)

cv2.imwrite("denoised.png", denoised)
print("[Receiver] Extracted message:", message)

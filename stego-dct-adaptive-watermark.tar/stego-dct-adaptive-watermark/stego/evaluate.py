from PIL import Image
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import sys

def evaluate_images(original_path, stego_path):
    # Mở ảnh và chuyển sang ảnh xám
    original = Image.open(original_path).convert('L')
    stego = Image.open(stego_path).convert('L')

    # Chuyển sang numpy array
    original_np = np.array(original, dtype=np.uint8)
    stego_np = np.array(stego, dtype=np.uint8)

    # Tính PSNR và SSIM
    psnr_value = psnr(original_np, stego_np)
    ssim_value = ssim(original_np, stego_np)

    print(f"PSNR (dB): {psnr_value:.2f}")
    print(f"SSIM     : {ssim_value:.4f}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python evaluate_quality.py <original_image> <stego_image>")
        sys.exit(1)
    
    original_path = sys.argv[1]
    stego_path = sys.argv[2]
    evaluate_images(original_path, stego_path)

import cv2
import numpy as np
from scipy.fftpack import dct, idct

np.random.seed(42)

def embed_watermark(img, watermark_bits, block_size=8, alpha=25):
    h, w = img.shape
    watermarked_img = img.copy()
    bit_idx = 0
    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            if bit_idx >= len(watermark_bits):
                break
            block = img[i:i+block_size, j:j+block_size]
            if block.shape != (block_size, block_size):
                continue
            dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
            coeff = dct_block[4, 4]
            dct_block[4, 4] = coeff + alpha if watermark_bits[bit_idx] == 1 else coeff - alpha
            idct_block = idct(idct(dct_block.T, norm='ortho').T, norm='ortho')
            watermarked_img[i:i+block_size, j:j+block_size] = np.clip(idct_block, 0, 255)
            bit_idx += 1
    return np.uint8(watermarked_img)

def add_gaussian_noise(image, mean=0, std=10):
    noise = np.random.normal(mean, std, image.shape)
    noisy_image = image + noise
    return np.uint8(np.clip(noisy_image, 0, 255))

# === MAIN ===
img = cv2.imread("lena.png", cv2.IMREAD_GRAYSCALE)
if img is None:
    print("Không đọc được file input.png")
    exit()

message = "HELLO"
binary = ''.join(format(ord(c), '08b') for c in message)
watermarked = embed_watermark(img, [int(b) for b in binary])
noisy = add_gaussian_noise(watermarked)

cv2.imwrite("watermarked_noisy.png", noisy)
print("[Sender] Đã giấu tin và thêm nhiễu.")
